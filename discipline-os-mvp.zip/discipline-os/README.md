# Discipline OS — MVP 0.4

Mobile-first Persian RTL accountability planner built with Next.js 15, React 19, TypeScript and optional Supabase cloud sync.

## Free-first architecture decision

**Keep Supabase as the optional cloud backend.** The existing application already uses Supabase Auth, Postgres and private Storage. Replacing it with Firebase/Appwrite would add migration work without making the core single-user planner meaningfully more free.

- **Offline/local mode:** tasks remain in the browser's local storage. JSON backup/export and restore are available from the Planner tab.
- **Cloud mode:** optional Supabase Free project for sign-in, database sync and private proof uploads.
- **AI penalties:** the app has a built-in no-cost safe fallback. An external AI API key is optional and may incur usage charges; do not add one if strict zero-cost operation is required.
- **Notifications:** foreground/browser notifications can be enabled by the user. Reliable notifications while the app is closed need a Push service worker, VAPID keys and a scheduled server process; they are not claimed as active in this release.

Supabase Free currently lists 500 MB database, 1 GB file storage, 5 GB egress and 50,000 monthly active users. Free projects may pause after a week of low activity, so cloud sync is convenient for a personal prototype but should not be treated as a guaranteed always-on production backend. See https://supabase.com/pricing and https://supabase.com/docs/guides/platform/free-project-pausing.

## Run locally (zero hosting cost)

Requirements: Node.js 20.9+

```bash
npm install
npm run dev
```

Open http://localhost:3000. Supabase is optional. Without environment variables the app runs in local mode.

## Optional Supabase cloud setup

1. Create a free project at https://supabase.com/dashboard.
2. In **SQL Editor**, run `supabase/schema.sql`.
3. Optionally run `supabase/schema-v0.4.sql` to prepare recurring templates and future push subscriptions.
4. In **Project Settings → API**, copy the Project URL and publishable/anon key.
5. Put them in `.env.local`:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY
   ```

6. In **Authentication → URL Configuration**, add `http://localhost:3000/auth/callback` to Redirect URLs.
7. Enable email OTP/magic links. Supabase's default email service has sending limits; custom SMTP may be needed for reliable use.
8. Restart the dev server and open `/login`.

Never expose a Supabase service-role key in browser code.

## v0.4 changes

- Added JSON export and restore for task data, so local-first users can back up without paying for cloud services.
- Updated project version and documentation around the free-first architecture.
- Added optional SQL migration for recurring task templates and per-user Push subscription storage (schema preparation only; recurring generation and background Push delivery are follow-up implementation tasks).

## Current limitations (transparent status)

- No public deployment has been performed; this is source code to run locally or deploy yourself.
- Deadline monitoring currently runs while the app is open. Browser notifications do not reliably fire when the app is closed.
- File import for PDF/Excel is a UI placeholder; automatic extraction is not implemented yet.
- Local proof files are browser-local. Cross-device proof storage requires Supabase sign-in and the private `proofs` bucket created by `schema.sql`.
- AI penalty generation uses a safe local fallback unless `OPENAI_API_KEY` is configured. An AI API is not free by default.
- Free Supabase projects can pause after a week of low activity and do not include automatic database backups.

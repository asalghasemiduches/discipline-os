# Discipline OS — MVP 0.3

Mobile-first Persian RTL accountability planner built with Next.js 15, React 19, TypeScript and Supabase.

## Run locally

- Node.js 20.9+
- `npm install`
- Copy `.env.example` to `.env.local` and fill in Supabase values
- `npm run dev`
- Open `http://localhost:3000`

## New in 0.3

- Passwordless email sign-in using Supabase Auth magic links.
- Auth callback route and browser session handling.
- Cloud task loading and upsert synchronization for authenticated users.
- Private proof upload to the Supabase `proofs` Storage bucket.
- Cloud penalty completion records.
- Updated SQL schema with owner-scoped RLS, composite ownership foreign key, unique task penalty and profile creation trigger.

## Supabase setup

1. Create a project at https://supabase.com/dashboard.
2. In **SQL Editor**, run the complete `supabase/schema.sql` file.
3. In **Project Settings → API**, copy the Project URL and publishable/anon key.
4. Put them in `.env.local`:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY
   ```

5. In **Authentication → URL Configuration**, add your local callback URL `http://localhost:3000/auth/callback` to Redirect URLs. When deployed, add `https://YOUR_DOMAIN/auth/callback` too.
6. In **Authentication → Providers → Email**, enable email OTP/magic links. Configure SMTP for reliable production delivery; Supabase's default mail service has sending limits.
7. Restart the dev server after changing `.env.local`.
8. Open `/login`, enter your email and follow the magic link.

## Data and security notes

- The public anon/publishable key is intended for browser use; row-level security protects user rows. Never expose a Supabase service-role key in client code.
- Cloud sync currently covers tasks and proof uploads. Existing local-only tasks are not automatically migrated; export/merge them before switching to cloud if they contain important data.
- Proof files are private. This release records the storage path; a signed-URL viewer is a follow-up feature.
- Deadline detection still runs in the open browser. Reliable closed-app reminders require Web Push subscriptions, VAPID configuration and a scheduled server worker; these are not claimed as active in this release.
- AI penalty suggestions require `OPENAI_API_KEY`; a safe local fallback is used otherwise.

import { NextResponse } from 'next/server';
import OpenAI from 'openai';
export async function POST(req: Request) {
  const { title, importance, category } = await req.json();
  if (!title) return NextResponse.json({ error: 'عنوان وظیفه الزامی است.' }, { status: 400 });
  if (!process.env.OPENAI_API_KEY) {
    const fallback = importance === 'زیاد' ? '۲۵ دقیقه تمرین جبرانی مرتبط با همین وظیفه' : importance === 'متوسط' ? '۱۵ دقیقه مرور یا تمرین تکمیلی' : '۱۰ دقیقه مرور و مرتب‌سازی برنامه فردا';
    return NextResponse.json({ penalty: fallback, source: 'safe-fallback' });
  }
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.chat.completions.create({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', temperature: 0.4, messages: [
    { role: 'system', content: 'You are a supportive accountability coach. Suggest exactly one short, constructive, non-harmful make-up action in Persian. Never suggest sleep/food/water deprivation, pain, humiliation, financial punishment, excessive exercise, or anything unsafe. Keep it proportionate, realistic, and related to the missed task. Return only the action, max 25 Persian words.' },
    { role: 'user', content: `وظیفه انجام‌نشده: ${title}\nاهمیت: ${importance}\nدسته: ${category}` }
  ] });
  return NextResponse.json({ penalty: response.choices[0]?.message?.content?.trim() || '۱۵ دقیقه مرور و تمرین تکمیلی' });
}

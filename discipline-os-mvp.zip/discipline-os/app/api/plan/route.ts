import { NextResponse } from 'next/server';
export async function POST() { return NextResponse.json({ message: 'استخراج برنامه از PDF و Excel در مرحله بعد پیاده‌سازی می‌شود.' }, { status: 501 }); }

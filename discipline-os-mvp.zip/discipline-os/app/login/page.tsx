'use client';
import { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Mail, ShieldCheck, Target } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function sendLink() {
    if (!email.trim()) return;
    const supabase = createClient();
    if (!supabase) { setMessage('ابتدا آدرس پروژه و کلید عمومی Supabase را در فایل .env.local تنظیم کن.'); return; }
    setBusy(true); setMessage('');
    const { error } = await supabase.auth.signInWithOtp({ email: email.trim(), options: { emailRedirectTo: `${location.origin}/auth/callback` } });
    setBusy(false);
    setMessage(error ? `خطا: ${error.message}` : 'لینک ورود برایت ایمیل شد. صندوق ورودی و پوشه Spam را بررسی کن.');
  }
  return <main className="app-shell min-h-screen flex flex-col justify-center px-5 py-10">
    <Link href="/" className="flex items-center gap-2 text-sm muted mb-8"><ArrowRight size={17}/> بازگشت به برنامه</Link>
    <div className="panel p-6">
      <div className="w-14 h-14 rounded-2xl bg-[#172b4d] text-[#d6b66a] flex items-center justify-center mb-5"><Target size={28}/></div>
      <div className="eyebrow">DISCIPLINE OS · CLOUD ACCOUNT</div>
      <h1 className="text-2xl font-bold mt-2">ورود به حساب کاربری</h1>
      <p className="small muted leading-7 mt-3">با ایمیل وارد شو تا وظایف و جریمه‌هایت در فضای ابری ذخیره شوند و بین دستگاه‌ها همگام‌سازی شوند.</p>
      <label className="block text-sm mt-6">آدرس ایمیل<input className="field mt-2" type="email" dir="ltr" autoComplete="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/></label>
      <button className="btn btn-primary w-full mt-4" disabled={busy || !email.includes('@')} onClick={sendLink}>{busy?'در حال ارسال...':'ارسال لینک ورود به ایمیل'} <Mail size={17}/></button>
      {message&&<p className="small leading-6 mt-4 text-[#167d65]">{message}</p>}
      <div className="flex gap-2 items-start mt-6 text-xs muted leading-6"><ShieldCheck size={16} className="shrink-0 mt-1"/> ورود بدون رمز عبور انجام می‌شود. لینک ورود فقط برای ایمیل خودت ارسال می‌شود.</div>
    </div>
  </main>;
}

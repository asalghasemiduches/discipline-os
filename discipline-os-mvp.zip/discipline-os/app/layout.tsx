import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Discipline OS | همراه نظم شخصی', description: 'برنامه‌ریز هوشمند، پیگیری وظایف و پاسخ‌گویی شخصی', manifest: '/manifest.json', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: 'Discipline OS' } };
export const viewport: Viewport = { themeColor: '#14243a', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="fa" dir="rtl"><body>{children}<script dangerouslySetInnerHTML={{__html:"if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(console.error));"}} /></body></html>; }

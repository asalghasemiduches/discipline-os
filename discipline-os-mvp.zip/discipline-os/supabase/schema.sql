-- Discipline OS cloud schema — run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  timezone text not null default 'Asia/Tehran',
  created_at timestamptz not null default now()
);
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null default 'شخصی',
  importance text not null default 'متوسط' check (importance in ('کم','متوسط','زیاد')),
  due_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending','completed','missed')),
  completed_at timestamptz,
  missed_at timestamptz,
  recurrence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id,user_id)
);
create index if not exists tasks_user_due_idx on public.tasks(user_id,due_at);
create table if not exists public.penalties (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  description text not null,
  status text not null default 'pending' check (status in ('pending','proof_submitted','completed','rejected')),
  proof_path text,
  proof_submitted_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(task_id),
  constraint penalties_task_owner_fk foreign key(task_id,user_id) references public.tasks(id,user_id) on delete cascade
);

alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.penalties enable row level security;
drop policy if exists "profiles own row" on public.profiles;
create policy "profiles own row" on public.profiles for all to authenticated using (auth.uid()=id) with check (auth.uid()=id);
drop policy if exists "tasks own rows" on public.tasks;
create policy "tasks own rows" on public.tasks for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
drop policy if exists "penalties own rows" on public.penalties;
create policy "penalties own rows" on public.penalties for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('proofs','proofs',false,10485760,array['image/jpeg','image/png','image/webp','video/mp4','application/pdf'])
on conflict (id) do update set public=false,file_size_limit=10485760,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "users upload own proof files" on storage.objects;
create policy "users upload own proof files" on storage.objects for insert to authenticated with check (bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "users read own proof files" on storage.objects;
create policy "users read own proof files" on storage.objects for select to authenticated using (bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "users update own proof files" on storage.objects;
create policy "users update own proof files" on storage.objects for update to authenticated using (bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1))) on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

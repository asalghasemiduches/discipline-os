-- Optional v0.4 migration: recurring plans and future Web Push subscriptions.
-- Run after schema.sql in Supabase SQL Editor.

create table if not exists public.recurring_task_templates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null default 'شخصی',
  importance text not null default 'متوسط' check (importance in ('کم','متوسط','زیاد')),
  due_time time not null,
  weekdays smallint[] not null default array[1,2,3,4,5,6,7],
  starts_on date not null default current_date,
  ends_on date,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint valid_weekdays check (weekdays <@ array[1,2,3,4,5,6,7]::smallint[]),
  constraint valid_template_dates check (ends_on is null or ends_on >= starts_on)
);

alter table public.tasks add column if not exists template_id uuid references public.recurring_task_templates(id) on delete set null;
alter table public.tasks add column if not exists scheduled_local_date date;
create unique index if not exists tasks_template_day_unique
  on public.tasks(template_id, scheduled_local_date)
  where template_id is not null and scheduled_local_date is not null;

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null,
  p256dh text not null,
  auth_secret text not null,
  created_at timestamptz not null default now(),
  unique(user_id, endpoint)
);

alter table public.recurring_task_templates enable row level security;
alter table public.push_subscriptions enable row level security;

drop policy if exists "users manage own recurring templates" on public.recurring_task_templates;
create policy "users manage own recurring templates" on public.recurring_task_templates
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "users manage own push subscriptions" on public.push_subscriptions;
create policy "users manage own push subscriptions" on public.push_subscriptions
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
